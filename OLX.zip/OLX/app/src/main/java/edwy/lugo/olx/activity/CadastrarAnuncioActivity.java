package edwy.lugo.olx.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import edwy.lugo.olx.R;

public class CadastrarAnuncioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_anuncio);
    }
}
